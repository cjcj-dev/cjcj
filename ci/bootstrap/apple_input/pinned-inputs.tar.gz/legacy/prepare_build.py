#!/usr/bin/env python3
"""Materialize only three complete packages and a first-error build command.

Preparation does not require BUILT receipts or run any tool. The caller supplies
an already verified, private copy of the complete official SDK and its lock.
"""
import argparse
import json
from pathlib import Path
import re
import shutil
from identity import FROZEN, sources, sdk, require, digest, entity, expected_sources


def prepare(root, output, inputs):
    sources(root, FROZEN['source_head'], FROZEN['inventory'])
    sdk(inputs['sdk_archive'], inputs['sdk_root'], json.loads(Path(inputs['sdk_lock']).read_text()), inputs['environment'], FROZEN['sdk_archive_sha256'])
    require(not output.exists(), 'build-output-exists')
    output.mkdir(parents=True)
    code = output / 'source'
    deltas = []
    for package in ('packages/basic','packages/utils','ci/bootstrap/signal_observation/native_fixture'):
        destination = code / package
        destination.mkdir(parents=True)
        for item in FROZEN['inventory']:
            relative = item['relative']
            if relative.startswith(package + '/'):
                p = code / relative
                p.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(root / relative,p)
        manifest = destination / 'cjpm.toml'
        before = manifest.read_text()
        text = re.sub(r'(?m)^(\s*(?:compile-option|override-compile-option)\s*=).*$',r'\1 "-O0 -g"',before)
        if package.endswith('native_fixture'):
            text = text.replace('${SIGNAL_FIXTURE_HELPER_O}', str(output/'helper.o'))
        manifest.write_text(text)
        deltas.append({'manifest':str(manifest),'before':before,'after':text,'sha256':digest(manifest)})
    (output/'manifest-deltas.json').write_text(json.dumps(deltas,indent=2)+'\n')
    helper = code/'ci/bootstrap/signal_observation/native_fixture/helper.c'
    fixture = helper.parent
    env = inputs['environment']
    sdkroot = inputs['apple_sdkroot']
    recipe = {'status':'PREPARED_NOT_AUTHORIZED','source_head':FROZEN['source_head'],'source_inventory':FROZEN['inventory'],'direct_std_packages':FROZEN['direct_std_packages'],'std_closure':FROZEN['std_closure'],'sdk_archive_sha256':FROZEN['sdk_archive_sha256'],'environment':env,'sdk_lock':inputs['sdk_lock'],'apple_sdkroot':sdkroot,'layout':inputs['layout'],'steps':[
        {'cwd':str(output),'argv':[inputs['sccache'],inputs['clang'],'-arch','arm64','-isysroot',sdkroot,'-O0','-g','-fno-lto','-pthread','-c',str(helper),'-o',str(output/'helper.o')]},
        {'cwd':str(fixture),'argv':[str(Path(inputs['sdk_root'])/'tools/bin/cjpm'),'build','-j',str(inputs['jobs']),'--target-dir',str(output/'target')]}
    ]}
    require(inputs['runner_platform'] == 'macOS' and inputs['jobs'] == inputs['runner_available_cores'] and inputs['jobs'] > 0, 'build-cores')
    recipe['inputs'] = inputs
    recipe['expected_sources'] = expected_sources(root)
    recipe['input_manifest'] = capture_inputs(output, inputs)
    (output/'input-manifest.json').write_text(json.dumps(recipe['input_manifest'],indent=2)+'\n')
    recipe['input_manifest_sha256'] = digest(output/'input-manifest.json')
    require(recipe['steps'] == fixed_steps(output, inputs), 'fixed-build-steps')
    (output/'build-recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
    return recipe


def capture_inputs(output, inputs):
    """Read entities without executing a tool. Repeated immediately pre-launch."""
    import os
    source = output/'source'
    inventory = []
    for p in sorted(source.rglob('*')):
        if p.is_file():
            inventory.append({'relative':p.relative_to(source).as_posix(),'sha256':digest(p)})
    tools = {}
    for name, path in {'compiler':str(Path(inputs['sdk_root'])/'bin/cjc'), 'cjpm':str(Path(inputs['sdk_root'])/'tools/bin/cjpm'), 'clang':inputs['clang'], 'sccache':inputs['sccache']}.items():
        p = Path(path)
        require(p.is_absolute() and p.is_file() and os.access(p, os.X_OK), 'tool-executable:'+name)
        tools[name] = {'path':str(p),'sha256':digest(p),'mode':p.stat().st_mode}
    sdk(inputs['sdk_archive'], inputs['sdk_root'],json.loads(Path(inputs['sdk_lock']).read_text()),inputs['environment'],FROZEN['sdk_archive_sha256'])
    return {'source':inventory,'manifest_deltas_sha256':digest(output/'manifest-deltas.json'),
            'sdk_archive_sha256':digest(inputs['sdk_archive']),'sdk_lock_sha256':digest(inputs['sdk_lock']), 'tools':tools}


def fixed_steps(output, inputs):
    fixture=output/'source/ci/bootstrap/signal_observation/native_fixture'
    return [
        {'cwd':str(output),'argv':[inputs['sccache'],inputs['clang'],'-arch','arm64','-isysroot',inputs['apple_sdkroot'],'-O0','-g','-fno-lto','-pthread','-c',str(fixture/'helper.c'),'-o',str(output/'helper.o')]},
        {'cwd':str(fixture),'argv':[str(Path(inputs['sdk_root'])/'tools/bin/cjpm'),'build','-j',str(inputs['jobs']),'--target-dir',str(output/'target')]}
    ]


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('source',type=Path); parser.add_argument('output',type=Path); parser.add_argument('inputs',type=Path)
    args=parser.parse_args()
    prepare(args.source.resolve(),args.output.resolve(),json.loads(args.inputs.read_text()))

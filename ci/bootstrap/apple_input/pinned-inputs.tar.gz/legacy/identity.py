"""Private, read-only identity validators. No compiler or native process launch."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import posixpath
import tarfile

HERE = Path(__file__).resolve().parent
FROZEN = json.loads((HERE / 'frozen-inputs.json').read_text())
PINS = json.loads((HERE / 'source-identity.json').read_text())


def require(ok, reason):
    print('CHECK '+reason+' '+('PASS' if ok else 'REJECT'), flush=True)
    if not ok:
        raise ValueError(reason)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def entity(item, reason):
    p = Path(item['path'])
    require(p.is_absolute() and p.is_file(), reason + '-path')
    require(digest(p) == item['sha256'], reason + '-hash')
    return p.resolve()


def calibration(path, identity_path, layout):
    pin = json.loads((HERE.parent / 'reviewed_calibration.json').read_text())
    require(digest(HERE.parent / 'reviewed_calibration.json') == PINS['reviewed_calibration_json_sha256'], 'calibration-pin')
    require(digest(HERE.parent / 'calibration_identity.json') == PINS['calibration_identity_json_sha256'], 'calibration-identity-pin')
    require(digest(path) == pin['files']['calibration.json'], 'calibration-entity')
    require(digest(identity_path) == pin['files']['identity.json'], 'calibration-identity')
    cal = json.loads(Path(path).read_text())
    require(cal['status'] == 'CALIBRATED' and cal['process_rc'] == 0, 'calibration-status')
    require(layout == cal['config']['layout'], 'calibration-layout')
    return cal, json.loads(Path(identity_path).read_text())


def sources(root, head, inventory):
    require(head == FROZEN['source_head'], 'source-head')
    expected = {i['relative']: i['sha256'] for i in FROZEN['inventory']}
    require(inventory == FROZEN['inventory'], 'source-inventory')
    actual = set()
    for package in ('packages/utils', 'packages/basic', 'ci/bootstrap/signal_observation/native_fixture'):
        for p in (Path(root) / package).rglob('*'):
            if p.is_file() and (p.suffix == '.cj' or p.name in ('cjpm.toml', 'helper.c')):
                actual.add(p.relative_to(root).as_posix())
    require(actual == set(expected), 'source-selection')
    for relative, sha in expected.items():
        require(digest(Path(root) / relative) == sha, 'source-content:' + relative)


def sdk(archive, root, lock, environment, expected_archive):
    """Verify every installed file against the immutable archive, including links.

    Tests call this validator with a labelled tiny transport archive; configure
    always supplies the registered official pin. No test path produces a config.
    """
    require(digest(archive) == expected_archive, 'sdk-archive')
    root = Path(root).resolve(strict=True)
    with tarfile.open(archive) as bundle:
        members = {}
        for m in bundle.getmembers():
            n = m.name.rstrip('/').removeprefix('./')
            require(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts, 'sdk-archive-path')
            if n == 'cangjie' or n.startswith('cangjie/'):
                require(n not in members, 'sdk-archive-duplicate')
                members[n] = m
        def resolve(name, seen=()):
            require(name in members and name not in seen, 'sdk-archive-link')
            m = members[name]
            if m.issym() or m.islnk():
                target = posixpath.normpath(posixpath.join(posixpath.dirname(name), m.linkname) if m.issym() else m.linkname.removeprefix('./'))
                require(target.startswith('cangjie/'), 'sdk-archive-link-root')
                return resolve(target, seen + (name,))
            require(m.isfile() or m.isdir(), 'sdk-archive-type')
            return m
        expected = {}
        for name in members:
            m = resolve(name)
            if m.isdir():
                continue
            relative = name.removeprefix('cangjie/')
            with bundle.extractfile(m) as stream:
                h = hashlib.sha256()
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    h.update(block)
                expected[relative] = h.hexdigest()
        require({'bin/cjc', 'tools/bin/cjpm'} <= expected.keys(), 'sdk-tools')
        require(any(n.startswith('lib/') for n in expected), 'sdk-std')
        require(any('libcangjie-runtime.dylib' in n for n in expected) and any('libboundscheck.dylib' in n for n in expected), 'sdk-runtime')
        require(any(n.startswith('third_party/llvm/') for n in expected), 'sdk-llvm')
        actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
        # SDK.lock is a private sidecar outside the unmodified official tree.
        require(actual == set(expected), 'sdk-file-set')
        for relative, sha in expected.items():
            p = root / relative
            require(p.resolve().is_relative_to(root), 'sdk-link-outside')
            require(digest(p) == sha, 'sdk-content:' + relative)
    require(lock == {'archive_sha256': expected_archive, 'files': expected}, 'sdk-lock')
    require(Path(environment['HOME']).is_dir() and Path(environment['TMPDIR']).is_dir(), 'environment-directories')
    require(environment['CANGJIE_HOME'] == str(root), 'environment-sdk')
    require(environment['PATH'] == str(root / 'bin') + ':' + str(root / 'tools/bin') + ':/usr/bin:/bin:/usr/sbin:/sbin', 'environment-tools')
    directories = [root / 'runtime/lib/darwin_aarch64_cjnative', root / 'lib/darwin_aarch64_cjnative', root / 'third_party/llvm/lib', root / 'tools/lib']
    require(environment['DYLD_LIBRARY_PATH'] == ':'.join(map(str, directories)), 'environment-loader')
    require(set(environment) == {'HOME','TMPDIR','PATH','CANGJIE_HOME','DYLD_LIBRARY_PATH'}, 'environment-extra')
    return expected


def evidence_refs(receipt):
    for key in ('unique_product_entry', 'normal_n2c_bridge', 'no_lto', 'selected_sources', 'std_inputs'):
        item = receipt['evidence'][key]
        require(Path(item['path']).is_file(), 'evidence-' + key + '-path')
        require(Path(item['path']).stat().st_size > 0, 'evidence-empty-' + key)
        entity(item, 'evidence-' + key)
        require(item['binary_sha256'] == receipt['binary_sha256'] and item['source_head'] == FROZEN['source_head'], 'evidence-binding-' + key)
        # References are original raw nm/otool/argv/selection records, not booleans.
    # These references bind transport only. Independent approval is separate.


def apple_headers(record, expected, layout):
    require(expected is not None, 'apple-headers-not-frozen')
    require(record == expected, 'apple-header-record')
    require(record['kind'] == 'actual-header-layout-capture' and bool(record['captured_at']) and bool(record['source_ref']), 'apple-header-provenance')
    require(record['xcode'] == 'Xcode 16.4\nBuild version 16F6\n' and record['sdk_version'] == '15.5', 'apple-header-sdk')
    require(record['layout'] == layout, 'apple-header-layout')
    require(bool(record['headers']), 'apple-header-empty')
    for item in record['headers']:
        entity(item, 'apple-header')
    entity(record['layout_evidence'], 'apple-layout-evidence')


def qualification(receipt, approval_ref):
    require(approval_ref is not None, 'qualification-not-authorized')
    approval = json.loads(entity(approval_ref, 'qualification-approval').read_text())
    require(approval['stage'] == 'native-qualification' and approval['decision'] == 'APPROVED', 'qualification-decision')
    require(approval['authority'] in ('independent-review', 'controller'), 'qualification-authority')
    require(approval['binary_sha256'] == receipt['binary_sha256'] and approval['source_head'] == receipt['fixture_source_head'], 'qualification-binding')
    require(approval['commands'] == receipt['build_commands'] and approval['raw_evidence'] == receipt['evidence'], 'qualification-raw-binding')
    require(approval['checks'] == {'unique_product_entry': True, 'normal_n2c_bridge': True, 'no_lto': True}, 'qualification-checks')


def expected_sources(root):
    """Package file candidates, not a claim about actual compiler selection.

    src-dir is read from these frozen simple manifests. @When stays within a
    source file; its Darwin branches are selected by the future real compiler.
    """
    import re
    result = []
    for package in ('packages/basic', 'packages/utils', 'ci/bootstrap/signal_observation/native_fixture'):
        manifest = Path(root) / package / 'cjpm.toml'
        match = re.search(r'^\s*src-dir\s*=\s*"([^"\n]+)"', manifest.read_text(), re.M)
        require(match is not None, 'manifest-src-dir')
        for p in sorted((manifest.parent / match[1]).rglob('*.cj')):
            relative = p.relative_to(root).as_posix()
            excluded = 'testdata' in p.parts or p.name.endswith('_test.cj')
            result.append({'relative': relative, 'expected_normal_input': not excluded,
                           'reason': 'test/testdata retained inventory' if excluded else 'cjpm src-dir candidate',
                           'platform_conditions': re.findall(r'@When\[([^\n]+)\]', p.read_text()),
                           'platform': 'macOS', 'actual_compiler_selection': 'NOT_CAPTURED'})
    return result
